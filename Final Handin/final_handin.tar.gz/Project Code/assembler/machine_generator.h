
#ifndef _MACHINE_GENERATOR_H__
#define _MACHINE_GENERATOR_H__

/*
  gets the machine encoding of a given instrucition.

  The first argument is the name of the instruction
  The second and third arguments are the arguments for the instruction
 */
int getEncodedInstruction(char**, char**, char**, int);

#endif
