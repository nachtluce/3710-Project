/*
  header file for command_converter.cpp
*/

#ifndef __COMMAND_CONVERTER_H__
#define __COMMAND_CONVERTER_H__

int GetRegisterValue(char *);

int GetOpCode(char *);

int GetOpExt(char *);

#endif
